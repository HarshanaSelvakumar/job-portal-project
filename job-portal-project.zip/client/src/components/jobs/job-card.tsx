import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Briefcase, 
  MapPin, 
  DollarSign, 
  Clock, 
  BarChart, 
  Code, 
  Database,
  Package
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Job } from "@shared/schema";

type JobCardProps = {
  job: Job;
};

export default function JobCard({ job }: JobCardProps) {
  const getJobIcon = (title: string) => {
    const lowerTitle = title.toLowerCase();
    if (lowerTitle.includes("data")) return <Database className="h-5 w-5" />;
    if (lowerTitle.includes("frontend") || lowerTitle.includes("ui") || lowerTitle.includes("front-end")) 
      return <Code className="h-5 w-5" />;
    if (lowerTitle.includes("product")) return <Package className="h-5 w-5" />;
    if (lowerTitle.includes("marketing")) return <BarChart className="h-5 w-5" />;
    return <Briefcase className="h-5 w-5" />;
  };

  return (
    <div className="px-4 py-4 sm:px-6 hover:bg-gray-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-700">
            {getJobIcon(job.title)}
          </div>
          <div className="ml-4">
            <Link href={`/jobs/${job.id}`}>
              <h4 className="text-sm font-medium text-primary-600 hover:text-primary-800 cursor-pointer">
                {job.title}
              </h4>
            </Link>
            <p className="text-sm text-gray-500">{job.company}</p>
          </div>
        </div>
        <div>
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
            {job.type}
          </span>
        </div>
      </div>
      <div className="mt-2 sm:flex sm:justify-between">
        <div className="sm:flex">
          <p className="flex items-center text-sm text-gray-500">
            <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
            <span>{job.location}</span>
          </p>
          <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
            <DollarSign className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
            <span>{job.salary}</span>
          </p>
        </div>
        <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
          <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
          <p>
            Posted {formatDistanceToNow(new Date(job.postedDate), { addSuffix: true })}
          </p>
        </div>
      </div>
      <div className="mt-2">
        <Link href={`/apply/${job.id}`}>
          <Button size="sm" className="h-8">Apply Now</Button>
        </Link>
      </div>
    </div>
  );
}
