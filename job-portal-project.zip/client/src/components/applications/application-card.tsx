import { Application, Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { 
  Building, 
  FileText, 
  CalendarDays 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

type ApplicationCardProps = {
  application: Application;
  job: Job;
};

export default function ApplicationCard({ application, job }: ApplicationCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Under Review
          </Badge>
        );
      case "interview":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Interview Scheduled
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
            Not Selected
          </Badge>
        );
      case "offered":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Offer Received
          </Badge>
        );
      case "accepted":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Accepted
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            {status}
          </Badge>
        );
    }
  };

  return (
    <div className="px-4 py-4 sm:px-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-700">
            <Building className="h-5 w-5" />
          </div>
          <div className="ml-4">
            <h4 className="text-sm font-medium text-gray-900">{job.title}</h4>
            <p className="text-sm text-gray-500">{job.company}</p>
          </div>
        </div>
        <div>
          {getStatusBadge(application.status)}
        </div>
      </div>
      <div className="mt-2 sm:flex sm:justify-between">
        <div className="sm:flex">
          <p className="flex items-center text-sm text-gray-500">
            <FileText className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
            <span>
              {application.resumeUrl ? "Resume submitted" : "Application submitted"}
            </span>
          </p>
        </div>
        <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
          <CalendarDays className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
          <p>
            Applied {formatDistanceToNow(new Date(application.appliedDate), { addSuffix: true })}
          </p>
        </div>
      </div>
    </div>
  );
}
