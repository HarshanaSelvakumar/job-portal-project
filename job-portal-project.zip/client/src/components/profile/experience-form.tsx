import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Experience } from "@shared/schema";
import { Pencil, Trash2, Plus } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const experienceSchema = z.object({
  company: z.string().min(1, "Company is required"),
  title: z.string().min(1, "Job title is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  current: z.boolean().default(false),
  description: z.string().optional(),
});

type ExperienceFormValues = z.infer<typeof experienceSchema>;

type ExperienceFormProps = {
  experiences: Experience[];
};

export default function ExperienceForm({ experiences }: ExperienceFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const form = useForm<ExperienceFormValues>({
    resolver: zodResolver(experienceSchema),
    defaultValues: {
      company: "",
      title: "",
      startDate: "",
      endDate: "",
      current: false,
      description: "",
    },
  });
  
  const createExperienceMutation = useMutation({
    mutationFn: async (values: ExperienceFormValues) => {
      const res = await apiRequest("POST", "/api/experiences", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experiences"] });
      toast({
        title: "Experience added",
        description: "Your work experience has been added successfully.",
      });
      setIsAdding(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add experience",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updateExperienceMutation = useMutation({
    mutationFn: async ({ id, values }: { id: number; values: ExperienceFormValues }) => {
      const res = await apiRequest("PUT", `/api/experiences/${id}`, values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experiences"] });
      toast({
        title: "Experience updated",
        description: "Your work experience has been updated successfully.",
      });
      setEditingId(null);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update experience",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const deleteExperienceMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/experiences/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/experiences"] });
      toast({
        title: "Experience deleted",
        description: "Your work experience has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete experience",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: ExperienceFormValues) => {
    if (editingId !== null) {
      updateExperienceMutation.mutate({ id: editingId, values });
    } else {
      createExperienceMutation.mutate(values);
    }
  };
  
  const startEditing = (experience: Experience) => {
    setEditingId(experience.id);
    form.reset({
      company: experience.company,
      title: experience.title,
      startDate: experience.startDate,
      endDate: experience.endDate || "",
      current: experience.current,
      description: experience.description || "",
    });
    setIsAdding(true);
  };
  
  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this experience?")) {
      deleteExperienceMutation.mutate(id);
    }
  };
  
  const handleCancel = () => {
    setIsAdding(false);
    setEditingId(null);
    form.reset();
  };

  return (
    <div>
      {experiences.length > 0 && !isAdding && (
        <div className="space-y-5">
          {experiences.map((experience) => (
            <div key={experience.id} className="border-b border-gray-200 pb-5 last:border-b-0 last:pb-0">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-md font-medium text-gray-900">{experience.title}</h4>
                  <p className="text-sm text-gray-600">{experience.company}</p>
                  <p className="text-sm text-gray-500">
                    {experience.startDate} - {experience.current ? "Present" : experience.endDate}
                  </p>
                  {experience.description && (
                    <p className="mt-2 text-sm text-gray-600">{experience.description}</p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => startEditing(experience)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleDelete(experience.id)}
                    disabled={deleteExperienceMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {isAdding ? (
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="company"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Company</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Company name" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Job Title</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Senior Developer" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="month"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Date</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="month"
                        disabled={form.watch("current")}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="current"
              render={({ field }) => (
                <div className="flex items-start space-x-2">
                  <Checkbox 
                    id="current-job" 
                    checked={field.value} 
                    onCheckedChange={field.onChange}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="current-job">
                      I currently work here
                    </Label>
                  </div>
                </div>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      rows={3} 
                      placeholder="Describe your responsibilities and achievements" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleCancel}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createExperienceMutation.isPending || updateExperienceMutation.isPending}
              >
                {editingId !== null ? "Update" : "Add"} Experience
              </Button>
            </div>
          </form>
        </Form>
      ) : (
        <div className="text-right">
          <Button 
            type="button" 
            onClick={() => setIsAdding(true)}
          >
            <Plus className="h-4 w-4 mr-2" /> Add Experience
          </Button>
        </div>
      )}
    </div>
  );
}
