import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import ResumeUpload from "@/components/profile/resume-upload";
import ExperienceForm from "@/components/profile/experience-form";
import { Loader2 } from "lucide-react";

const profileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address").min(1, "Email is required"),
  headline: z.string().optional(),
  about: z.string().optional(),
  phone: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [resumeUrl, setResumeUrl] = useState<string | null>(user?.resumeUrl || null);
  
  // Fetch user experiences
  const { data: experiences, isLoading: isLoadingExperiences } = useQuery({
    queryKey: ["/api/experiences"],
  });

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      headline: user?.headline || "",
      about: user?.about || "",
      phone: user?.phone || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (values: ProfileFormValues) => {
      const res = await apiRequest("PUT", "/api/profile", values);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ProfileFormValues) => {
    updateProfileMutation.mutate(values);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="md:grid md:grid-cols-3 md:gap-6">
          <div className="md:col-span-1">
            <div className="px-4 sm:px-0">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Profile Information</h3>
              <p className="mt-1 text-sm text-gray-600">
                This information will be displayed publicly so be careful what you share.
              </p>
            </div>
          </div>
          <div className="mt-5 md:mt-0 md:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <div className="shadow sm:rounded-md sm:overflow-hidden">
                  <div className="px-4 py-5 bg-white space-y-6 sm:p-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem className="grid grid-cols-3 gap-6">
                          <FormLabel className="col-span-3 sm:col-span-1 flex items-center">
                            Full Name
                          </FormLabel>
                          <div className="col-span-3 sm:col-span-2">
                            <FormControl>
                              <Input {...field} placeholder="John Doe" />
                            </FormControl>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem className="grid grid-cols-3 gap-6">
                          <FormLabel className="col-span-3 sm:col-span-1 flex items-center">
                            Email Address
                          </FormLabel>
                          <div className="col-span-3 sm:col-span-2">
                            <FormControl>
                              <Input {...field} type="email" placeholder="john@example.com" />
                            </FormControl>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem className="grid grid-cols-3 gap-6">
                          <FormLabel className="col-span-3 sm:col-span-1 flex items-center">
                            Phone Number
                          </FormLabel>
                          <div className="col-span-3 sm:col-span-2">
                            <FormControl>
                              <Input {...field} placeholder="(555) 123-4567" />
                            </FormControl>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="headline"
                      render={({ field }) => (
                        <FormItem className="grid grid-cols-3 gap-6">
                          <FormLabel className="col-span-3 sm:col-span-1 flex items-center">
                            Professional Headline
                          </FormLabel>
                          <div className="col-span-3 sm:col-span-2">
                            <FormControl>
                              <Input 
                                {...field} 
                                placeholder="Senior Software Engineer with 5+ years experience" 
                              />
                            </FormControl>
                            <FormMessage />
                            <p className="mt-2 text-sm text-gray-500">
                              Brief description for your profile.
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="about"
                      render={({ field }) => (
                        <FormItem className="grid grid-cols-3 gap-6">
                          <FormLabel className="col-span-3 sm:col-span-1 flex items-center">
                            About
                          </FormLabel>
                          <div className="col-span-3 sm:col-span-2">
                            <FormControl>
                              <Textarea 
                                {...field} 
                                rows={3} 
                                placeholder="Tell us about your skills and experience" 
                              />
                            </FormControl>
                            <FormMessage />
                            <p className="mt-2 text-sm text-gray-500">
                              Brief description for your profile.
                            </p>
                          </div>
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-3 gap-6">
                      <div className="col-span-3 sm:col-span-1 flex items-center">
                        <span className="block text-sm font-medium text-gray-700">
                          Resume
                        </span>
                      </div>
                      <div className="col-span-3 sm:col-span-2">
                        <ResumeUpload 
                          resumeUrl={resumeUrl} 
                          onUploadSuccess={(url) => setResumeUrl(url)} 
                        />
                      </div>
                    </div>
                  </div>
                  <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? (
                        <span className="flex items-center">
                          <span className="mr-2">Saving</span>
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </span>
                      ) : "Save"}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="md:grid md:grid-cols-3 md:gap-6">
          <div className="md:col-span-1">
            <div className="px-4 sm:px-0">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Experience</h3>
              <p className="mt-1 text-sm text-gray-600">
                Share your work history to improve job recommendations.
              </p>
            </div>
          </div>
          <div className="mt-5 md:mt-0 md:col-span-2">
            <div className="shadow sm:rounded-md sm:overflow-hidden">
              <div className="px-4 py-5 bg-white space-y-6 sm:p-6">
                {isLoadingExperiences ? (
                  <div className="py-6 flex justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : (
                  <ExperienceForm experiences={experiences || []} />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
