import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import JobCard from "@/components/jobs/job-card";
import ApplicationCard from "@/components/applications/application-card";
import JobSearchForm from "@/components/jobs/job-search-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Loader2, UserCog } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  
  // Fetch recommended jobs (all jobs for now)
  const { data: jobs, isLoading: isLoadingJobs } = useQuery({
    queryKey: ["/api/jobs"],
  });

  // Fetch recent applications for the user
  const { data: applications, isLoading: isLoadingApplications } = useQuery({
    queryKey: ["/api/applications"],
  });

  // Stats for the dashboard
  const stats = [
    {
      title: "Applications Submitted",
      value: applications?.length || 0,
    },
    {
      title: "Applications Under Review",
      value: applications?.filter(item => item.application.status === "pending").length || 0,
    },
    {
      title: "Interviews Scheduled",
      value: applications?.filter(item => item.application.status === "interview").length || 0,
    },
    {
      title: "Profile Completion",
      value: user?.resumeUrl ? "85%" : "50%",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Dashboard Header with Stats */}
        <div className="md:flex md:items-center md:justify-between mb-6">
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Welcome back, {user?.name?.split(' ')[0] || user?.username}!
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              Here's your job search progress
            </p>
          </div>
          <div className="mt-4 flex md:mt-0 md:ml-4">
            <Link href="/profile">
              <Button className="ml-3 inline-flex items-center">
                <UserCog className="h-5 w-5 mr-2" />
                Update Profile
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <Card key={index} className="shadow">
              <CardContent className="px-4 py-5 sm:p-6">
                <dt className="text-sm font-medium text-gray-500 truncate">
                  {stat.title}
                </dt>
                <dd className="mt-1 text-3xl font-semibold text-gray-900">
                  {stat.value}
                </dd>
              </CardContent>
            </Card>
          ))}
        </div>
        
        {/* Search and Recommended Jobs Section */}
        <div className="mt-8">
          <h2 className="text-lg leading-6 font-medium text-gray-900 mb-4">Find Your Next Opportunity</h2>
          
          {/* Search Form */}
          <Card className="shadow mb-6">
            <CardContent className="px-4 py-5 sm:p-6">
              <JobSearchForm />
            </CardContent>
          </Card>
          
          {/* Recommended Jobs */}
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Recommended Jobs</h3>
          <Card className="overflow-hidden shadow">
            {isLoadingJobs ? (
              <div className="p-8 flex justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : jobs && jobs.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {jobs.slice(0, 3).map((job) => (
                  <li key={job.id}>
                    <JobCard job={job} />
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-8 text-center text-gray-500">
                No jobs found. Check back later for new opportunities.
              </div>
            )}
          </Card>
        </div>
        
        {/* Recent Applications */}
        <div className="mt-8">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Your Recent Applications</h3>
          <Card className="overflow-hidden shadow">
            {isLoadingApplications ? (
              <div className="p-8 flex justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : applications && applications.length > 0 ? (
              <ul className="divide-y divide-gray-200">
                {applications.slice(0, 3).map((application) => (
                  <li key={application.application.id}>
                    <ApplicationCard
                      application={application.application}
                      job={application.job}
                    />
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-8 text-center text-gray-500">
                You haven't applied to any jobs yet. Start browsing jobs to apply!
              </div>
            )}
            {applications && applications.length > 0 && (
              <div className="px-4 py-4 sm:px-6 text-center">
                <Link href="/applications">
                  <Button variant="outline">View All Applications</Button>
                </Link>
              </div>
            )}
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
