import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

const applicationSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address").min(1, "Email is required"),
  phone: z.string().optional(),
  coverLetter: z.string().optional(),
  terms: z.boolean().refine(value => value === true, {
    message: "You must agree to the terms and conditions",
  }),
});

type ApplicationFormValues = z.infer<typeof applicationSchema>;

export default function JobApplicationPage() {
  const { id } = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  
  // Fetch job details
  const { data: job, isLoading: isLoadingJob } = useQuery({
    queryKey: [`/api/jobs/${id}`],
    enabled: !!id,
  });
  
  const form = useForm<ApplicationFormValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      firstName: user?.name ? user.name.split(' ')[0] : "",
      lastName: user?.name ? user.name.split(' ').slice(1).join(' ') : "",
      email: user?.email || "",
      phone: user?.phone || "",
      coverLetter: "",
      terms: false,
    },
  });
  
  const submitApplicationMutation = useMutation({
    mutationFn: async (values: FormData) => {
      const res = await fetch(`/api/applications`, {
        method: "POST",
        body: values,
        credentials: "include",
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to submit application");
      }
      
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      toast({
        title: "Application submitted",
        description: "Your job application has been submitted successfully.",
      });
      navigate("/applications");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to submit application",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: ApplicationFormValues) => {
    if (!id) {
      toast({
        title: "Error",
        description: "Job ID is missing",
        variant: "destructive",
      });
      return;
    }
    
    const formData = new FormData();
    formData.append("jobId", id);
    formData.append("coverLetter", values.coverLetter || "");
    
    if (file) {
      formData.append("resume", file);
    }
    
    submitApplicationMutation.mutate(formData);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFile(e.target.files[0]);
    }
  };
  
  if (isLoadingJob) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }
  
  if (!job) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow container mx-auto px-4 py-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Job Not Found</h2>
          <p className="text-gray-600 mb-6">The job you're applying for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate("/jobs")}>Browse All Jobs</Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="md:grid md:grid-cols-3 md:gap-6 mb-8">
          <div className="md:col-span-1">
            <div className="px-4 sm:px-0">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Job Application</h3>
              <p className="mt-1 text-sm text-gray-600">
                Submit your application for the {job.title} position at {job.company}.
              </p>
            </div>
          </div>
          <div className="mt-5 md:mt-0 md:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)}>
                <div className="shadow overflow-hidden sm:rounded-md">
                  <div className="px-4 py-5 bg-white sm:p-6">
                    <div className="grid grid-cols-6 gap-6">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem className="col-span-6 sm:col-span-3">
                            <FormLabel>First name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem className="col-span-6 sm:col-span-3">
                            <FormLabel>Last name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem className="col-span-6 sm:col-span-4">
                            <FormLabel>Email address</FormLabel>
                            <FormControl>
                              <Input {...field} type="email" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem className="col-span-6 sm:col-span-3">
                            <FormLabel>Phone number</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="(555) 123-4567" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="coverLetter"
                        render={({ field }) => (
                          <FormItem className="col-span-6">
                            <FormLabel>Cover Letter</FormLabel>
                            <FormControl>
                              <Textarea 
                                {...field} 
                                rows={4} 
                                placeholder="Why are you interested in this position? What makes you a good fit?" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="col-span-6">
                        <Label>Resume</Label>
                        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                          <div className="space-y-1 text-center">
                            {file ? (
                              <div className="flex flex-col items-center">
                                <div className="flex items-center text-sm text-primary-600">
                                  <span className="font-medium">{file.name}</span>
                                  <span className="ml-2">({Math.round(file.size / 1024)} KB)</span>
                                </div>
                                <Button 
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="mt-2 text-red-600 hover:text-red-800"
                                  onClick={() => setFile(null)}
                                >
                                  Remove
                                </Button>
                              </div>
                            ) : (
                              <>
                                <svg
                                  className="mx-auto h-12 w-12 text-gray-400"
                                  stroke="currentColor"
                                  fill="none"
                                  viewBox="0 0 48 48"
                                  aria-hidden="true"
                                >
                                  <path
                                    d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                                    strokeWidth={2}
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                </svg>
                                <div className="flex text-sm text-gray-600">
                                  <label
                                    htmlFor="file-upload"
                                    className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none"
                                  >
                                    <span>Upload a file</span>
                                    <input
                                      id="file-upload"
                                      name="file-upload"
                                      type="file"
                                      className="sr-only"
                                      accept=".pdf,.doc,.docx"
                                      onChange={handleFileChange}
                                    />
                                  </label>
                                  <p className="pl-1">or drag and drop</p>
                                </div>
                                <p className="text-xs text-gray-500">
                                  PDF, DOC up to 10MB
                                </p>
                                {user?.resumeUrl && (
                                  <p className="text-xs text-gray-500 mt-1">
                                    If you don't upload a resume, we'll use the one in your profile.
                                  </p>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="terms"
                        render={({ field }) => (
                          <FormItem className="col-span-6">
                            <div className="flex items-start">
                              <div className="flex items-center h-5">
                                <FormControl>
                                  <Checkbox
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                    id="terms"
                                  />
                                </FormControl>
                              </div>
                              <div className="ml-3 text-sm">
                                <Label htmlFor="terms" className="font-medium text-gray-700">I agree to the terms and conditions</Label>
                                <p className="text-gray-500">By applying, you agree to our privacy policy and consent to being contacted regarding this position.</p>
                              </div>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
                    <Button
                      type="button"
                      variant="outline"
                      className="mr-3"
                      onClick={() => navigate(`/jobs/${id}`)}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={submitApplicationMutation.isPending}
                    >
                      {submitApplicationMutation.isPending ? (
                        <span className="flex items-center">
                          <span className="mr-2">Submitting</span>
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </span>
                      ) : "Submit Application"}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
