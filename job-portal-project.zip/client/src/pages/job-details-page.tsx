import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import { Job } from "@shared/schema";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Briefcase,
  Building,
  MapPin,
  DollarSign,
  Clock,
  Calendar,
  Users,
  GraduationCap,
  BookmarkIcon,
  Share2,
  Send,
  ChevronRight
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Loader2 } from "lucide-react";

export default function JobDetailsPage() {
  const params = useParams<{ id: string }>();
  const [_, navigate] = useLocation();
  const [similarJobs, setSimilarJobs] = useState<Job[]>([]);
  
  // Fetch job details
  const { data: job, isLoading, error } = useQuery<Job>({
    queryKey: [`/api/jobs/${params.id}`],
    enabled: !!params.id,
  });
  
  // Fetch all jobs to get similar ones
  const { data: allJobs } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
    onSuccess: (data) => {
      if (job) {
        // Filter similar jobs by excluding current job and limiting to 3
        const filtered = data
          .filter(j => j.id !== job.id)
          .slice(0, 3);
        setSimilarJobs(filtered);
      }
    }
  });
  
  // Parse requirements and skills for better display
  const formatRequirements = (text?: string) => {
    if (!text) return [];
    return text.split('\n').filter(line => line.trim().length > 0);
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
        <Footer />
      </div>
    );
  }
  
  if (error || !job) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow container mx-auto px-4 py-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Job Not Found</h2>
          <p className="text-gray-600 mb-6">The job you're looking for doesn't exist or has been removed.</p>
          <Link href="/jobs">
            <Button>Browse All Jobs</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const requirementsList = formatRequirements(job.requirements);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="lg:grid lg:grid-cols-12 lg:gap-x-5">
          <div className="space-y-6 lg:px-0 lg:col-span-8">
            <Card className="shadow">
              <CardContent className="p-6">
                <div className="md:flex md:items-center md:justify-between mb-6">
                  <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                      {job.title}
                    </h2>
                    <div className="mt-1 flex flex-col sm:flex-row sm:flex-wrap sm:mt-0 sm:space-x-6">
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Building className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                        <span>{job.company}</span>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <MapPin className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                        <span>{job.location}</span>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <DollarSign className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                        <span>{job.salary}</span>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <Clock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                        <span>{job.type}</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-5 flex lg:mt-0 lg:ml-4">
                    <span className="hidden sm:block mr-3">
                      <Button variant="outline" size="sm" className="flex items-center">
                        <BookmarkIcon className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                    </span>
                    <span className="hidden sm:block mr-3">
                      <Button variant="outline" size="sm" className="flex items-center">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </span>
                    <span>
                      <Button 
                        size="sm" 
                        className="flex items-center"
                        onClick={() => navigate(`/apply/${job.id}`)}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Apply
                      </Button>
                    </span>
                  </div>
                </div>
                
                <div className="prose max-w-none">
                  <div className="mb-6">
                    <h3 className="text-lg font-medium leading-6 text-gray-900">Company Overview</h3>
                    <p className="mt-2 text-base text-gray-500">
                      {job.company} is a leading company in the {job.title.split(' ')[0]} industry.
                    </p>
                  </div>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium leading-6 text-gray-900">Job Description</h3>
                    <p className="mt-2 text-base text-gray-500">
                      {job.description}
                    </p>
                  </div>
                  
                  {requirementsList.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">Requirements</h3>
                      <ul className="mt-2 text-base text-gray-500 list-disc pl-5 space-y-1">
                        {requirementsList.map((req, index) => (
                          <li key={index}>{req}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {job.skills && job.skills.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-lg font-medium leading-6 text-gray-900">Skills</h3>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {job.skills.map((skill, index) => (
                          <Badge 
                            key={index} 
                            variant="outline" 
                            className="bg-primary-100 text-primary-800 hover:bg-primary-100"
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-medium leading-6 text-gray-900">Benefits</h3>
                    <ul className="mt-2 text-base text-gray-500 list-disc pl-5 space-y-1">
                      <li>{job.salary} based on experience</li>
                      <li>Comprehensive health, dental, and vision insurance</li>
                      <li>Flexible working arrangements</li>
                      <li>Career development opportunities</li>
                      <li>Collaborative and innovative work environment</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-6 sm:px-6 lg:px-0 lg:col-span-4">
            <Card className="shadow">
              <CardContent className="p-6">
                <div className="mb-5">
                  <h3 className="text-lg font-medium leading-6 text-gray-900">Job Overview</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Calendar className="mt-0.5 h-5 w-5 text-gray-400" />
                    </div>
                    <div className="ml-3 text-sm">
                      <span className="text-gray-700 font-medium">Posted On:</span>
                      <p className="text-gray-500">
                        {job.postedDate ? formatDistanceToNow(new Date(job.postedDate), { addSuffix: true }) : "Recently"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Users className="mt-0.5 h-5 w-5 text-gray-400" />
                    </div>
                    <div className="ml-3 text-sm">
                      <span className="text-gray-700 font-medium">Job Type:</span>
                      <p className="text-gray-500">{job.type}</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <Briefcase className="mt-0.5 h-5 w-5 text-gray-400" />
                    </div>
                    <div className="ml-3 text-sm">
                      <span className="text-gray-700 font-medium">Experience:</span>
                      <p className="text-gray-500">
                        {job.title.toLowerCase().includes("senior") ? "5+ years" : 
                         job.title.toLowerCase().includes("junior") ? "1-3 years" : "3+ years"}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <GraduationCap className="mt-0.5 h-5 w-5 text-gray-400" />
                    </div>
                    <div className="ml-3 text-sm">
                      <span className="text-gray-700 font-medium">Education:</span>
                      <p className="text-gray-500">Bachelor's Degree</p>
                    </div>
                  </div>
                  
                  {job.skills && job.skills.length > 0 && (
                    <div className="pt-5">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Key Skills</h4>
                      <div className="flex flex-wrap gap-2">
                        {job.skills.slice(0, 6).map((skill, index) => (
                          <Badge 
                            key={index} 
                            variant="outline" 
                            className="bg-primary-100 text-primary-800 hover:bg-primary-100"
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="mt-8">
                  <Button 
                    className="w-full"
                    onClick={() => navigate(`/apply/${job.id}`)}
                  >
                    Apply Now
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow">
              <CardContent className="p-6">
                <div className="mb-5">
                  <h3 className="text-lg font-medium leading-6 text-gray-900">Similar Jobs</h3>
                </div>
                
                <div className="space-y-4">
                  {similarJobs.length > 0 ? (
                    similarJobs.map((similarJob) => (
                      <div key={similarJob.id} className="border-b border-gray-200 pb-4 last:border-b-0 last:pb-0">
                        <Link href={`/jobs/${similarJob.id}`}>
                          <div className="text-sm font-medium text-primary-600 hover:text-primary-800 cursor-pointer">
                            {similarJob.title}
                          </div>
                        </Link>
                        <div className="mt-1 flex items-center text-xs text-gray-500">
                          <span>{similarJob.company}</span>
                          <span className="mx-1">•</span>
                          <span>{similarJob.location}</span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-gray-500">No similar jobs found.</div>
                  )}
                </div>
                
                <div className="mt-5 text-center">
                  <Link href="/jobs">
                    <Button variant="link" size="sm" className="text-primary-600">
                      View more similar jobs
                      <ChevronRight className="ml-1 h-3 w-3" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
