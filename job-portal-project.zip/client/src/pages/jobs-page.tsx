import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import JobCard from "@/components/jobs/job-card";
import JobSearchForm from "@/components/jobs/job-search-form";
import { Card, CardContent } from "@/components/ui/card";
import { Job } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

export default function JobsPage() {
  const [location, setLocation] = useLocation();
  const [searchParams, setSearchParams] = useState<Record<string, string>>({});
  
  // Parse URL query parameters
  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const newParams: Record<string, string> = {};
    
    for (const [key, value] of params.entries()) {
      newParams[key] = value;
    }
    
    setSearchParams(newParams);
  }, [location]);
  
  // Fetch jobs based on filters
  const { data: jobs, isLoading } = useQuery({
    queryKey: ["/api/jobs", searchParams],
    queryFn: async ({ queryKey }) => {
      const [_, filters] = queryKey;
      const params = new URLSearchParams();
      
      for (const [key, value] of Object.entries(filters as Record<string, string>)) {
        if (value) params.append(key, value);
      }
      
      const queryString = params.toString();
      const response = await fetch(`/api/jobs${queryString ? `?${queryString}` : ""}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch jobs");
      }
      
      return response.json();
    },
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="w-full lg:w-1/3 lg:max-w-md">
            <Card className="sticky top-24 shadow">
              <CardContent className="px-4 py-5 sm:p-6">
                <h2 className="text-lg font-bold mb-4">Search Jobs</h2>
                <JobSearchForm />
              </CardContent>
            </Card>
          </div>
          
          <div className="w-full lg:w-2/3">
            <h1 className="text-2xl font-bold mb-4">Available Jobs</h1>
            
            {/* Applied filters */}
            {Object.keys(searchParams).length > 0 && (
              <div className="mb-4">
                <h2 className="text-sm text-gray-500 mb-1">Filtered by:</h2>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(searchParams).map(([key, value]) => 
                    value && (
                      <span key={key} className="px-2 py-1 bg-gray-100 rounded-md text-sm">
                        {key}: {value}
                      </span>
                    )
                  )}
                </div>
              </div>
            )}
            
            <Card className="shadow mb-4">
              {isLoading ? (
                <div className="p-12 flex justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : jobs && jobs.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {jobs.map((job: Job) => (
                    <li key={job.id}>
                      <JobCard job={job} />
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="p-12 text-center">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
                  <p className="text-gray-500">
                    Try adjusting your search filters or check back later for new opportunities.
                  </p>
                </div>
              )}
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
