import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/ui/layout/navbar";
import Footer from "@/components/ui/layout/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import {
  Building,
  MapPin,
  Calendar,
  Clock,
  ChevronRight,
  FileText,
  ExternalLink,
  Loader2
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import { Application, Job } from "@shared/schema";

// Type for application with job data
type ApplicationWithJob = {
  application: Application;
  job: Job;
};

export default function ApplicationsPage() {
  const [activeTab, setActiveTab] = useState("all");
  
  // Fetch user applications
  const { data: applications, isLoading } = useQuery<ApplicationWithJob[]>({
    queryKey: ["/api/applications"],
  });
  
  // Filter applications based on active tab
  const getFilteredApplications = () => {
    if (!applications) return [];
    
    if (activeTab === "all") return applications;
    
    return applications.filter((app) => {
      switch (activeTab) {
        case "pending":
          return app.application.status === "pending";
        case "interview":
          return app.application.status === "interview";
        case "offered":
          return app.application.status === "offered";
        case "rejected":
          return app.application.status === "rejected";
        default:
          return true;
      }
    });
  };
  
  // Get counts for each status category
  const getCounts = () => {
    if (!applications) return { all: 0, pending: 0, interview: 0, offered: 0, rejected: 0 };
    
    return {
      all: applications.length,
      pending: applications.filter(app => app.application.status === "pending").length,
      interview: applications.filter(app => app.application.status === "interview").length,
      offered: applications.filter(app => app.application.status === "offered").length,
      rejected: applications.filter(app => app.application.status === "rejected").length
    };
  };
  
  const counts = getCounts();
  const filteredApplications = getFilteredApplications();
  
  // Get status badge for each application
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Under Review
          </Badge>
        );
      case "interview":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Interview Scheduled
          </Badge>
        );
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">
            Not Selected
          </Badge>
        );
      case "offered":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            Offer Received
          </Badge>
        );
      case "accepted":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
            Accepted
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 hover:bg-gray-100">
            {status}
          </Badge>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            My Applications
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Track and manage your job applications
          </p>
        </div>
        
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="all">
                All Applications
                {counts.all > 0 && <span className="ml-1.5 bg-gray-100 text-gray-700 py-0.5 px-2 rounded-full text-xs">{counts.all}</span>}
              </TabsTrigger>
              <TabsTrigger value="pending">
                Under Review
                {counts.pending > 0 && <span className="ml-1.5 bg-yellow-100 text-yellow-700 py-0.5 px-2 rounded-full text-xs">{counts.pending}</span>}
              </TabsTrigger>
              <TabsTrigger value="interview">
                Interview
                {counts.interview > 0 && <span className="ml-1.5 bg-green-100 text-green-700 py-0.5 px-2 rounded-full text-xs">{counts.interview}</span>}
              </TabsTrigger>
              <TabsTrigger value="offered">
                Offered
                {counts.offered > 0 && <span className="ml-1.5 bg-blue-100 text-blue-700 py-0.5 px-2 rounded-full text-xs">{counts.offered}</span>}
              </TabsTrigger>
              <TabsTrigger value="rejected">
                Rejected
                {counts.rejected > 0 && <span className="ml-1.5 bg-red-100 text-red-700 py-0.5 px-2 rounded-full text-xs">{counts.rejected}</span>}
              </TabsTrigger>
            </TabsList>
            
            <Link href="/jobs">
              <Button variant="outline" size="sm">
                Browse Jobs
              </Button>
            </Link>
          </div>
          
          <TabsContent value={activeTab}>
            {isLoading ? (
              <div className="flex justify-center p-12">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
              </div>
            ) : filteredApplications.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredApplications.map(({ application, job }) => (
                  <Card key={application.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg font-semibold">{job.title}</CardTitle>
                          <div className="text-sm text-gray-500 mt-1">{job.company}</div>
                        </div>
                        {getStatusBadge(application.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center text-sm text-gray-500">
                          <MapPin className="mr-2 h-4 w-4 text-gray-400" />
                          {job.location}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                          Applied on {format(new Date(application.appliedDate), "MMM d, yyyy")}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="mr-2 h-4 w-4 text-gray-400" />
                          {formatDistanceToNow(new Date(application.appliedDate), { addSuffix: true })}
                        </div>
                        {application.resumeUrl && (
                          <div className="flex items-center text-sm text-gray-500">
                            <FileText className="mr-2 h-4 w-4 text-gray-400" />
                            Resume submitted
                          </div>
                        )}
                      </div>
                      
                      <div className="mt-4 border-t border-gray-200 pt-4 flex flex-wrap gap-2">
                        <Link href={`/jobs/${job.id}`}>
                          <Button variant="outline" size="sm" className="flex items-center">
                            <ExternalLink className="mr-1 h-3 w-3" />
                            View Job
                          </Button>
                        </Link>
                        {application.status === "pending" && (
                          <Link href={`/apply/${job.id}`}>
                            <Button size="sm" variant="outline">
                              Update Application
                            </Button>
                          </Link>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No applications found</h3>
                  <p className="text-gray-500 mb-6">
                    {activeTab === "all"
                      ? "You haven't applied to any jobs yet."
                      : `You don't have any applications with '${activeTab}' status.`}
                  </p>
                  <Link href="/jobs">
                    <Button>
                      Browse Jobs
                      <ChevronRight className="ml-1 h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
    </div>
  );
}
