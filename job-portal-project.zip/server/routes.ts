import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(import.meta.dirname, "../uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage: storage_config,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB max
  },
  fileFilter: (req, file, cb) => {
    // Accept PDF, DOC, DOCX
    const filetypes = /pdf|doc|docx/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    
    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error("Only PDF, DOC, and DOCX files are allowed"));
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Profile routes
  app.put("/api/profile", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const { name, email, headline, about, phone } = req.body;
      
      const updatedUser = await storage.updateUser(userId, {
        name,
        email,
        headline,
        about,
        phone
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const userResponse = { ...updatedUser } as any;
      delete userResponse.password;
      
      res.json(userResponse);
    } catch (error) {
      res.status(500).json({ message: "Error updating profile" });
    }
  });
  
  // Resume upload
  app.post("/api/profile/resume", upload.single("resume"), async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const file = req.file;
      
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const resumeUrl = `/uploads/${file.filename}`;
      const updatedUser = await storage.updateUser(userId, { resumeUrl });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ resumeUrl });
    } catch (error) {
      res.status(500).json({ message: "Error uploading resume" });
    }
  });
  
  // Experience routes
  app.get("/api/experiences", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const experiences = await storage.getExperiencesByUserId(userId);
      res.json(experiences);
    } catch (error) {
      res.status(500).json({ message: "Error fetching experiences" });
    }
  });
  
  app.post("/api/experiences", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const { company, title, startDate, endDate, current, description } = req.body;
      
      const experience = await storage.createExperience({
        userId,
        company,
        title,
        startDate,
        endDate: current ? null : endDate,
        current: !!current,
        description
      });
      
      res.status(201).json(experience);
    } catch (error) {
      res.status(500).json({ message: "Error creating experience" });
    }
  });
  
  app.put("/api/experiences/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const { id } = req.params;
      const { company, title, startDate, endDate, current, description } = req.body;
      
      const updatedExperience = await storage.updateExperience(Number(id), {
        company,
        title,
        startDate,
        endDate: current ? null : endDate,
        current: !!current,
        description
      });
      
      if (!updatedExperience) {
        return res.status(404).json({ message: "Experience not found" });
      }
      
      res.json(updatedExperience);
    } catch (error) {
      res.status(500).json({ message: "Error updating experience" });
    }
  });
  
  app.delete("/api/experiences/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const { id } = req.params;
      const success = await storage.deleteExperience(Number(id));
      
      if (!success) {
        return res.status(404).json({ message: "Experience not found" });
      }
      
      res.sendStatus(204);
    } catch (error) {
      res.status(500).json({ message: "Error deleting experience" });
    }
  });
  
  // Job routes
  app.get("/api/jobs", async (req: Request, res: Response) => {
    try {
      const { title, location, type } = req.query;
      const filters: any = {};
      
      if (title) filters.title = title as string;
      if (location) filters.location = location as string;
      if (type) filters.type = type as string;
      
      const jobs = await storage.getJobs(filters);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Error fetching jobs" });
    }
  });
  
  app.get("/api/jobs/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const job = await storage.getJob(Number(id));
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: "Error fetching job" });
    }
  });
  
  // Application routes
  app.get("/api/applications", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const applications = await storage.getApplicationsByUserId(userId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Error fetching applications" });
    }
  });
  
  app.post("/api/applications", upload.single("resume"), async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const { jobId, coverLetter } = req.body;
      
      if (!jobId) {
        return res.status(400).json({ message: "Job ID is required" });
      }
      
      // Handle optional resume upload
      let resumeUrl = req.user!.resumeUrl;
      if (req.file) {
        resumeUrl = `/uploads/${req.file.filename}`;
      }
      
      const application = await storage.createApplication({
        userId,
        jobId: Number(jobId),
        coverLetter,
        resumeUrl
      });
      
      res.status(201).json(application);
    } catch (error) {
      res.status(500).json({ message: "Error submitting application" });
    }
  });
  
  app.get("/api/applications/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    
    try {
      const { id } = req.params;
      const result = await storage.getApplicationWithJob(Number(id));
      
      if (!result) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Check if the application belongs to the authenticated user
      if (result.application.userId !== req.user!.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Error fetching application" });
    }
  });

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthenticated" });
    }
    next();
  }, express.static(uploadDir as string));

  const httpServer = createServer(app);

  return httpServer;
}
