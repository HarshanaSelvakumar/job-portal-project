import { users, type User, type InsertUser, jobs, type Job, type InsertJob, applications, type Application, type InsertApplication, experiences, type Experience, type InsertExperience } from "@shared/schema";
import session from "express-session";
import { eq, and, like, desc, or } from "drizzle-orm";
import { db } from "./db";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import createMemoryStore from "memorystore";

const PostgresSessionStore = connectPg(session);
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Job operations
  getJobs(filters?: Partial<{title: string, location: string, type: string}>): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  
  // Application operations
  getApplications(userId: number): Promise<Application[]>;
  getApplicationWithJob(id: number): Promise<{application: Application, job: Job} | undefined>;
  getApplicationsByUserId(userId: number): Promise<{application: Application, job: Job}[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplicationStatus(id: number, status: string): Promise<Application | undefined>;
  
  // Experience operations
  getExperiencesByUserId(userId: number): Promise<Experience[]>;
  createExperience(experience: InsertExperience): Promise<Experience>;
  updateExperience(id: number, experience: Partial<Experience>): Promise<Experience | undefined>;
  deleteExperience(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private jobsMap: Map<number, Job>;
  private applicationsMap: Map<number, Application>;
  private experiencesMap: Map<number, Experience>;
  
  private userId: number;
  private jobId: number;
  private applicationId: number;
  private experienceId: number;
  
  sessionStore: any;

  constructor() {
    this.usersMap = new Map();
    this.jobsMap = new Map();
    this.applicationsMap = new Map();
    this.experiencesMap = new Map();
    
    this.userId = 1;
    this.jobId = 1;
    this.applicationId = 1;
    this.experienceId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Seed with some sample jobs
    this.seedJobs();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersMap.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.usersMap.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersMap.set(id, updatedUser);
    return updatedUser;
  }
  
  // Job operations
  async getJobs(filters?: Partial<{title: string, location: string, type: string}>): Promise<Job[]> {
    let jobs = Array.from(this.jobsMap.values());
    
    if (filters) {
      if (filters.title) {
        jobs = jobs.filter(job => 
          job.title.toLowerCase().includes(filters.title!.toLowerCase())
        );
      }
      
      if (filters.location) {
        jobs = jobs.filter(job => 
          job.location.toLowerCase().includes(filters.location!.toLowerCase())
        );
      }
      
      if (filters.type) {
        jobs = jobs.filter(job => job.type === filters.type);
      }
    }
    
    return jobs;
  }
  
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobsMap.get(id);
  }
  
  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.jobId++;
    const now = new Date();
    const job: Job = { 
      ...insertJob, 
      id, 
      postedDate: now 
    };
    this.jobsMap.set(id, job);
    return job;
  }
  
  // Application operations
  async getApplications(userId: number): Promise<Application[]> {
    return Array.from(this.applicationsMap.values()).filter(
      app => app.userId === userId
    );
  }
  
  async getApplicationWithJob(id: number): Promise<{application: Application, job: Job} | undefined> {
    const application = this.applicationsMap.get(id);
    if (!application) return undefined;
    
    const job = this.jobsMap.get(application.jobId);
    if (!job) return undefined;
    
    return { application, job };
  }
  
  async getApplicationsByUserId(userId: number): Promise<{application: Application, job: Job}[]> {
    const applications = Array.from(this.applicationsMap.values()).filter(
      app => app.userId === userId
    );
    
    return applications.map(application => {
      const job = this.jobsMap.get(application.jobId)!;
      return { application, job };
    }).filter(item => item.job !== undefined);
  }
  
  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.applicationId++;
    const now = new Date();
    const application: Application = {
      ...insertApplication,
      id,
      status: "pending",
      appliedDate: now
    };
    this.applicationsMap.set(id, application);
    return application;
  }
  
  async updateApplicationStatus(id: number, status: string): Promise<Application | undefined> {
    const application = this.applicationsMap.get(id);
    if (!application) return undefined;
    
    const updatedApplication = { ...application, status };
    this.applicationsMap.set(id, updatedApplication);
    return updatedApplication;
  }
  
  // Experience operations
  async getExperiencesByUserId(userId: number): Promise<Experience[]> {
    return Array.from(this.experiencesMap.values()).filter(
      exp => exp.userId === userId
    );
  }
  
  async createExperience(insertExperience: InsertExperience): Promise<Experience> {
    const id = this.experienceId++;
    const experience: Experience = { ...insertExperience, id };
    this.experiencesMap.set(id, experience);
    return experience;
  }
  
  async updateExperience(id: number, experienceData: Partial<Experience>): Promise<Experience | undefined> {
    const experience = this.experiencesMap.get(id);
    if (!experience) return undefined;
    
    const updatedExperience = { ...experience, ...experienceData };
    this.experiencesMap.set(id, updatedExperience);
    return updatedExperience;
  }
  
  async deleteExperience(id: number): Promise<boolean> {
    return this.experiencesMap.delete(id);
  }
  
  // Helper method to seed initial job data
  private seedJobs(): void {
    const sampleJobs: InsertJob[] = [
      {
        title: "Senior Software Engineer",
        company: "TechCorp Inc.",
        location: "San Francisco, CA",
        type: "Full-time",
        description: "We are looking for a Senior Software Engineer to join our growing engineering team. You will be responsible for designing, implementing, and maintaining high-performance, scalable software solutions.",
        requirements: "5+ years of professional software development experience\nStrong proficiency in JavaScript, TypeScript, and React\nExperience with backend technologies like Node.js, Python, or Java\nFamiliarity with cloud platforms (AWS, GCP, or Azure)\nUnderstanding of CI/CD practices and DevOps principles\nExcellent problem-solving and communication skills\nBS/MS in Computer Science or equivalent practical experience",
        salary: "$120K - $150K",
        skills: ["JavaScript", "TypeScript", "React", "Node.js", "AWS", "CI/CD"]
      },
      {
        title: "Frontend Developer",
        company: "WebSolutions Ltd.",
        location: "Remote",
        type: "Full-time",
        description: "Join our team as a Frontend Developer and help us build beautiful, responsive web applications for our clients.",
        requirements: "3+ years of experience with HTML, CSS, and JavaScript\nProficiency with React, Vue, or Angular\nFamiliarity with responsive design principles\nStrong attention to detail and UI/UX sensibilities\nAbility to work in a remote team environment",
        salary: "$90K - $110K",
        skills: ["JavaScript", "React", "HTML", "CSS", "Responsive Design"]
      },
      {
        title: "Data Analyst",
        company: "DataInsights Co.",
        location: "Chicago, IL",
        type: "Contract",
        description: "We're seeking a skilled Data Analyst to help extract insights from our customer data and improve business decision-making.",
        requirements: "Experience with SQL and data analysis tools\nProficiency with Excel and data visualization tools\nFamiliarity with statistical analysis\nStrong analytical thinking and problem-solving abilities",
        salary: "$40/hr",
        skills: ["SQL", "Excel", "Data Visualization", "Statistical Analysis"]
      },
      {
        title: "Product Designer",
        company: "DesignStudio Inc.",
        location: "New York, NY",
        type: "Full-time",
        description: "Join our creative team as a Product Designer to help craft intuitive and beautiful digital experiences for our clients.",
        requirements: "3+ years of experience in product or UX design\nStrong portfolio demonstrating your design process\nProficiency with Figma, Sketch, or Adobe XD\nExperience with user research and usability testing\nAbility to work collaboratively with developers and stakeholders",
        salary: "$95K - $120K",
        skills: ["UI/UX", "Figma", "User Research", "Prototyping"]
      },
      {
        title: "Full Stack Developer",
        company: "TechStart Inc.",
        location: "Austin, TX",
        type: "Full-time",
        description: "We're looking for a versatile Full Stack Developer who can work on both frontend and backend technologies in our fast-paced startup environment.",
        requirements: "Experience with JavaScript/TypeScript on both frontend and backend\nProficiency with React and Node.js\nFamiliarity with databases (SQL or NoSQL)\nUnderstanding of RESTful APIs and microservices architecture\nPassion for clean, maintainable code",
        salary: "$100K - $130K",
        skills: ["JavaScript", "React", "Node.js", "MongoDB", "REST API"]
      },
      {
        title: "Marketing Specialist",
        company: "GrowthMarketing LLC",
        location: "Boston, MA",
        type: "Full-time",
        description: "We're seeking a Marketing Specialist to help develop and execute marketing campaigns across multiple channels.",
        requirements: "2+ years of experience in digital marketing\nProficiency with SEO, SEM, and social media marketing\nExperience with marketing analytics tools\nStrong written and verbal communication skills\nCreativity and strategic thinking abilities",
        salary: "$70K - $85K",
        skills: ["Digital Marketing", "SEO", "Social Media", "Analytics"]
      }
    ];
    
    sampleJobs.forEach(job => {
      const id = this.jobId++;
      const now = new Date();
      this.jobsMap.set(id, { ...job, id, postedDate: now });
    });
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Ensure all nullable fields have explicit null values instead of undefined
    const userData = {
      ...insertUser,
      name: insertUser.name || null,
      email: insertUser.email || null
    };
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    // Ensure all nullable fields have explicit null values instead of undefined
    const processedData: Partial<User> = {};
    
    // Process each field to handle undefined values
    for (const [key, value] of Object.entries(userData)) {
      if (value === undefined) {
        processedData[key as keyof User] = null;
      } else {
        processedData[key as keyof User] = value;
      }
    }
    
    const [updatedUser] = await db
      .update(users)
      .set(processedData)
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser;
  }
  
  // Job operations
  async getJobs(filters?: Partial<{title: string, location: string, type: string}>): Promise<Job[]> {
    let query = db.select().from(jobs);
    
    if (filters) {
      const conditions = [];
      
      if (filters.title) {
        conditions.push(like(jobs.title, `%${filters.title}%`));
      }
      
      if (filters.location) {
        conditions.push(like(jobs.location, `%${filters.location}%`));
      }
      
      if (filters.type) {
        conditions.push(eq(jobs.type, filters.type));
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
    }
    
    // Sort by most recent
    query = query.orderBy(desc(jobs.postedDate));
    
    return await query;
  }
  
  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }
  
  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(insertJob).returning();
    return job;
  }
  
  // Application operations
  async getApplications(userId: number): Promise<Application[]> {
    return await db
      .select()
      .from(applications)
      .where(eq(applications.userId, userId));
  }
  
  async getApplicationWithJob(id: number): Promise<{application: Application, job: Job} | undefined> {
    const [application] = await db
      .select()
      .from(applications)
      .where(eq(applications.id, id));
    
    if (!application) return undefined;
    
    const [job] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, application.jobId));
    
    if (!job) return undefined;
    
    return { application, job };
  }
  
  async getApplicationsByUserId(userId: number): Promise<{application: Application, job: Job}[]> {
    const results = await db
      .select({
        application: applications,
        job: jobs
      })
      .from(applications)
      .innerJoin(jobs, eq(applications.jobId, jobs.id))
      .where(eq(applications.userId, userId));
    
    return results;
  }
  
  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    // Ensure all nullable fields have explicit null values
    const applicationData = {
      ...insertApplication,
      status: "pending",
      resumeUrl: insertApplication.resumeUrl || null,
      coverLetter: insertApplication.coverLetter || null
      // appliedDate is handled by defaultNow() in the schema
    };
    
    const [application] = await db
      .insert(applications)
      .values(applicationData)
      .returning();
    
    return application;
  }
  
  async updateApplicationStatus(id: number, status: string): Promise<Application | undefined> {
    const [updatedApplication] = await db
      .update(applications)
      .set({ status })
      .where(eq(applications.id, id))
      .returning();
    
    return updatedApplication;
  }
  
  // Experience operations
  async getExperiencesByUserId(userId: number): Promise<Experience[]> {
    return await db
      .select()
      .from(experiences)
      .where(eq(experiences.userId, userId));
  }
  
  async createExperience(insertExperience: InsertExperience): Promise<Experience> {
    // Ensure all nullable fields have explicit null values
    const experienceData = {
      ...insertExperience,
      description: insertExperience.description || null,
      endDate: insertExperience.endDate || null,
      current: insertExperience.current ?? false
    };
    
    const [experience] = await db
      .insert(experiences)
      .values(experienceData)
      .returning();
    
    return experience;
  }
  
  async updateExperience(id: number, experienceData: Partial<Experience>): Promise<Experience | undefined> {
    const [updatedExperience] = await db
      .update(experiences)
      .set(experienceData)
      .where(eq(experiences.id, id))
      .returning();
    
    return updatedExperience;
  }
  
  async deleteExperience(id: number): Promise<boolean> {
    await db
      .delete(experiences)
      .where(eq(experiences.id, id));
    
    return true;
  }
}

// Replace memory storage with database storage
export const storage = new DatabaseStorage();
