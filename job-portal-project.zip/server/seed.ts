import { db } from "./db";
import { jobs } from "@shared/schema";

async function seed() {
  // Check if we already have jobs
  const existingJobs = await db.select().from(jobs);
  
  if (existingJobs.length > 0) {
    console.log("Database already seeded with jobs");
    return;
  }

  const sampleJobs = [
    {
      title: "Senior Software Engineer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      type: "Full-time",
      description: "We are looking for a Senior Software Engineer to join our growing engineering team. You will be responsible for designing, implementing, and maintaining high-performance, scalable software solutions.",
      requirements: "5+ years of professional software development experience\nStrong proficiency in JavaScript, TypeScript, and React\nExperience with backend technologies like Node.js, Python, or Java\nFamiliarity with cloud platforms (AWS, GCP, or Azure)\nUnderstanding of CI/CD practices and DevOps principles\nExcellent problem-solving and communication skills\nBS/MS in Computer Science or equivalent practical experience",
      salary: "$120K - $150K",
      skills: ["JavaScript", "TypeScript", "React", "Node.js", "AWS", "CI/CD"],
    },
    {
      title: "Frontend Developer",
      company: "WebSolutions Ltd.",
      location: "Remote",
      type: "Full-time",
      description: "Join our team as a Frontend Developer and help us build beautiful, responsive web applications for our clients.",
      requirements: "3+ years of experience with HTML, CSS, and JavaScript\nProficiency with React, Vue, or Angular\nFamiliarity with responsive design principles\nStrong attention to detail and UI/UX sensibilities\nAbility to work in a remote team environment",
      salary: "$90K - $110K",
      skills: ["JavaScript", "React", "HTML", "CSS", "Responsive Design"],
    },
    {
      title: "Data Analyst",
      company: "DataInsights Co.",
      location: "Chicago, IL",
      type: "Contract",
      description: "We're seeking a skilled Data Analyst to help extract insights from our customer data and improve business decision-making.",
      requirements: "Experience with SQL and data analysis tools\nProficiency with Excel and data visualization tools\nFamiliarity with statistical analysis\nStrong analytical thinking and problem-solving abilities",
      salary: "$40/hr",
      skills: ["SQL", "Excel", "Data Visualization", "Statistical Analysis"],
    },
    {
      title: "Product Designer",
      company: "DesignStudio Inc.",
      location: "New York, NY",
      type: "Full-time",
      description: "Join our creative team as a Product Designer to help craft intuitive and beautiful digital experiences for our clients.",
      requirements: "3+ years of experience in product or UX design\nStrong portfolio demonstrating your design process\nProficiency with Figma, Sketch, or Adobe XD\nExperience with user research and usability testing\nAbility to work collaboratively with developers and stakeholders",
      salary: "$95K - $120K",
      skills: ["UI/UX", "Figma", "User Research", "Prototyping"],
    },
    {
      title: "Full Stack Developer",
      company: "TechStart Inc.",
      location: "Austin, TX",
      type: "Full-time",
      description: "We're looking for a versatile Full Stack Developer who can work on both frontend and backend technologies in our fast-paced startup environment.",
      requirements: "Experience with JavaScript/TypeScript on both frontend and backend\nProficiency with React and Node.js\nFamiliarity with databases (SQL or NoSQL)\nUnderstanding of RESTful APIs and microservices architecture\nPassion for clean, maintainable code",
      salary: "$100K - $130K",
      skills: ["JavaScript", "React", "Node.js", "MongoDB", "REST API"],
    },
    {
      title: "Marketing Specialist",
      company: "GrowthMarketing LLC",
      location: "Boston, MA",
      type: "Full-time",
      description: "We're seeking a Marketing Specialist to help develop and execute marketing campaigns across multiple channels.",
      requirements: "2+ years of experience in digital marketing\nProficiency with SEO, SEM, and social media marketing\nExperience with marketing analytics tools\nStrong written and verbal communication skills\nCreativity and strategic thinking abilities",
      salary: "$70K - $85K",
      skills: ["Digital Marketing", "SEO", "Social Media", "Analytics"],
    }
  ];

  console.log("Seeding database with job data...");
  
  for (const job of sampleJobs) {
    await db.insert(jobs).values(job);
  }
  
  console.log("Database seeded successfully!");
}

seed().catch(error => {
  console.error("Error seeding database:", error);
  process.exit(1);
});